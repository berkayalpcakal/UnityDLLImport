/*
 * simpleSum_private.h
 *
 * Code generation for model "simpleSum".
 *
 * Model version              : 1.6
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri Oct 25 15:31:56 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_simpleSum_private_h_
#define RTW_HEADER_simpleSum_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#endif                                 /* RTW_HEADER_simpleSum_private_h_ */
