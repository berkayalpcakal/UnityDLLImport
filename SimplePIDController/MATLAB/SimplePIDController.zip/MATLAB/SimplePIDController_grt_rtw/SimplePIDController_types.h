/*
 * SimplePIDController_types.h
 *
 * Code generation for model "SimplePIDController".
 *
 * Model version              : 1.4
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri Oct 25 16:31:17 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Debugging
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SimplePIDController_types_h_
#define RTW_HEADER_SimplePIDController_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (default storage) */
typedef struct P_SimplePIDController_T_ P_SimplePIDController_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_SimplePIDController_T RT_MODEL_SimplePIDController_T;

#endif                             /* RTW_HEADER_SimplePIDController_types_h_ */
